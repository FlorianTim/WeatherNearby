# LumbreCode Icon Pack

Erstellt aus dem freigegebenen LumbreCode-Glühbirnenzeichen.

## Enthaltene Varianten

### Master
- `master/lumbrecode_icon_master.svg`
- `master/lumbrecode_icon_master_1024.png`
- transparente Flat- und Monochrom-Varianten
- `master/lumbrecode_google_play_512.png`

### Flutter / Android
- klassische `mipmap-*` Launcher-Icons
- adaptive Vordergrund-Layer in 108 / 162 / 216 / 324 / 432 px
- monochrome Layer für Android-Themed-Icons
- `mipmap-anydpi-v26` und `mipmap-anydpi-v33`
- Manifest-Beispiel und `flutter_launcher_icons.yaml.example`

Kopiere den Inhalt von:

`flutter/android/app/src/main/res/`

nach:

`android/app/src/main/res/`

### Flutter / iOS
Komplettes:

`flutter/ios/Runner/Assets.xcassets/AppIcon.appiconset/`

Der 1024px-Master ist deckend und enthält keine Transparenz.

### Web / Flutter Web
- `favicon.ico`, SVG- und PNG-Favicons
- `apple-touch-icon.png`
- Flutter-Standardnamen `Icon-192.png` und `Icon-512.png`
- maskierbare PWA-Icons
- `site.webmanifest`
- `index-head-snippet.html`

Kopiere den Inhalt von `web/` in das `web/`-Verzeichnis des Flutter-Projekts.

## Farben
- Hintergrund: `#070A10`
- Hauptakzent: `#FF9F1C`

## Gestaltungslogik
- große App- und Store-Icons: dezenter Leuchteffekt
- adaptive Vordergründe: schattenfreie, saubere Vektorkanten
- kleine Favicons: reduzierte Flat-Variante für bessere Lesbarkeit
